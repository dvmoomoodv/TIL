import { Component } from '@angular/core';

@Component({
  selector: 'intro',
  template: `생명주기 장의 예제 파일입니다.<br>
  브라우저를 이용하신다면 콘솔 창(디버깅 창) 오픈 후 테스트를 진행해주세요`
})
export class IntroComponent {}