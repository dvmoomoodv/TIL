import { Component } from '@angular/core';

@Component({
  selector: 'href-test',
  template: `<a href="/href-test">현재 페이지</a> <br>`
})
export class HrefTestComponent { }