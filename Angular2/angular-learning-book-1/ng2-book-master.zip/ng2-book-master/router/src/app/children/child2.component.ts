import { Component } from '@angular/core';

@Component({
  selector: 'child2',
  template: `
  <h3>자식2</h3>`
})
export class Child2Component { }