import { Component } from '@angular/core';

@Component({
  selector: 'player',
  template: `<h3>운영자만 볼 수 있는 Player 화면 입니다.</h3>`
})
export class PlayerComponent { }