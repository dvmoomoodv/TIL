import { Component } from '@angular/core';

@Component({
  selector: 'intro',
  template: `모듈 장의 예제 파일입니다.`  
})
export class IntroComponent {}