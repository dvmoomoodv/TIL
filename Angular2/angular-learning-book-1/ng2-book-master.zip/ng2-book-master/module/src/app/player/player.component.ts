import { Component } from '@angular/core';

@Component({
  selector: 'player',
  template: `<div highlight>{{"player!!!"|myupper}}</div>`
})
export class PlayerComponent { }