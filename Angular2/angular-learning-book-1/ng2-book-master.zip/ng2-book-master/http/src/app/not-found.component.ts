import { Component } from '@angular/core';

@Component({
  selector: 'not-found',
  template: `<h3>요청하신 페이지가 존재하지 않습니다.</h3>`
})
export class NotFoundComponent { }