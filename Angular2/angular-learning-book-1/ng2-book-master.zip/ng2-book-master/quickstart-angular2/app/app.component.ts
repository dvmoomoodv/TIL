import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1>Hello Angular 2 Application</h1>'
})
export class AppComponent { }