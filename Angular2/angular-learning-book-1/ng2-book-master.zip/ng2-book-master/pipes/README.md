# 정정사항

예제 11.5의 경로를 다음과 같이 정정합니다.

/pipes/custom-replace/custom-replace.component.ts -> /pipes/src/app/custom-replace/replace.pipe.ts