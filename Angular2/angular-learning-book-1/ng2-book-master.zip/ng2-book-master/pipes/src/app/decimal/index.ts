export * from './decimal.component';
