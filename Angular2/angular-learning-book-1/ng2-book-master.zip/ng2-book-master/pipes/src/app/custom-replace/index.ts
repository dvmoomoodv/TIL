export * from './replace.component';
