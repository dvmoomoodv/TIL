import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'use-cmp',
  template: '',
  styles:['']
})
export class UseComponent{
  constructor() {}
}
