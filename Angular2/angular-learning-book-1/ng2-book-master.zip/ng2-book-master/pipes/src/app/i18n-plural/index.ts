export * from './i18n-plural.component';
