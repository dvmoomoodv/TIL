export * from './slice.component';
