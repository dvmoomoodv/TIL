export * from './percent.component';
