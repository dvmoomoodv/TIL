export { BasicComponent } from './basic.component';
