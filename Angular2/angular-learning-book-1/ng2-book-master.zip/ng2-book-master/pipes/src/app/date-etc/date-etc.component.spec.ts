/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import {
  beforeEach, beforeEachProviders,
  describe, xdescribe,
  expect, it, xit,
  async, inject
} from '@angular/core/testing';

import { DateEtcComponent } from './date-etc.component';

describe('Component: DateEtc', () => {
  it('should create an instance', () => {
    let component = new DateEtcComponent();
    expect(component).toBeTruthy();
  });
});
