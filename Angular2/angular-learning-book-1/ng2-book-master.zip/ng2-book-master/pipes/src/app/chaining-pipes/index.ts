export * from './chaining-pipes.component';
