import { User } from './user';

export var USER: User[] = [
  {name: '유비',id:'1'},
  {name: '관우',id:'2'},
  {name: '장비',id:'3'}  
];