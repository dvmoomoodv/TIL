import { User } from './user';

export var USERS: User[] = [
  { name: '조조', id: '1' },
  { name: '하우돈', id: '2' },
  { name: '허저', id: '3' }
];