export class User {
  name: string;
  id: string;
}