import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'highlight-cmp',
  template: `<div highlight>안녕하세요</div>`,  
})
export class HighlightComponent{}
