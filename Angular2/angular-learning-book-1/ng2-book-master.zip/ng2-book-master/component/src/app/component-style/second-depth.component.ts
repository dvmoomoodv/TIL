import { Component } from '@angular/core';

@Component({
  selector: 'second-depth',
  template: `<div class="second">2번째 깊이</div>`
})
export class SecondDepthComponent {}