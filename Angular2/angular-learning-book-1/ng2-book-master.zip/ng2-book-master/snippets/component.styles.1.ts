import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<span>Hello</span>`,
  styles: ['span { font-style: italic; font-size: 50px; }']
})
export class AppComponent { }