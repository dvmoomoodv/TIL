import { LifecycleHooks } from './private_import_core';
export declare function hasLifecycleHook(hook: LifecycleHooks, token: any): boolean;
